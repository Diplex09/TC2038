README, by Aldo Degollado & Diego Velázquez

Actividad integradora 2

El archivo cpp resuelve los primeros 3 problemas presentados en la activida, la manera en que funciona
es leyendo el Case1.txt que en el primer reglon checa el tamaño de la matriz y despues los valores de la matriz.

4 <----- numero de la matriz

0 16 45 32      /
16  0 18 21   <| --------- Los valores para resolver el problema 1 y 2
45 18  0  7     \
32 21  7  0

0 48  12  18       /
52  0 42 32      <| --------- Los valores para resolver el problema 3
18 46  0 56        \
24 36 52  0      

En el archivo py hacemos el ultimo problema de actividad que desplegara las coordenadas que se realizan con el diagrama de voronoi.
El archivo lee el Case1.txt pero solo toma en cuenta los ultimos valores.

(200,500) 
(300,100) 
(450,150) 
(520,480)

