
README
This activity does a merge sort where you input how many numbers you want to order, then the numbers to order and it will order them in an ascendent form. The program runs with the command prompt.

Caso de uso 1 
Input (Number of numbers to sort): 4
Input (Number): 3.94,3.92,10.1,2.5 
Output : 10.1,3.94,3.92,2.5 

Caso de uso 2 
Input (Number of numbers to sort): 3 
Input (Number): -2.5,-2.1,-1.2 
Output : -1.2,-2.1,-2.5 

Caso de uso 3 Input (Number of numbers to sort): 5 
Input (Number): 1,2,3,4,5 
Output : 5,4,3,2,1 

Caso de uso 4 
Input (Number of numbers to sort): 5 
Input (Number): 1,2,-3,4,5 
Output : 5,4,2,1,-3 

Caso de uso 5 
Input (Number of numbers to sort):6 
Input (Number): 1,2,3,3,4,5 
Output : 5,4,3,3,2,1}